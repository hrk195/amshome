# AMS for Samsung — bản iOS (Flutter)

Bản dựng lại app **AMS** (com.acacy.ewo_ams v1.0.3.4) chạy trên iPhone, viết bằng Flutter.
Giao diện bám theo bản Android gốc: cùng bộ chữ tiếng Việt, cùng bộ icon menu, cùng màu chủ đạo `#0B7EBA`.

---

## 1. Đã kiểm tra những gì

| Hạng mục | Kết quả |
|---|---|
| `flutter analyze` | **0 error** |
| `flutter test` | **3/3 pass** (màn đăng nhập, nạp bộ ngôn ngữ, 40 module) |
| `flutter build web --release` | **build thành công** |
| Render giao diện | Đã chụp ảnh màn đăng nhập + trang chủ, icon và chữ hiển thị đúng |
| Build `.ipa` | **Chưa build ở đây** — cần macOS + Xcode. Dùng workflow có sẵn (mục 3) |

Nói thẳng: toàn bộ code đã biên dịch và test thật, nhưng **file .ipa chưa được tạo ra** vì máy này không có macOS.

---

## 2. Đã làm được gì

### Nền tảng
- Đăng nhập thật qua API `POST /api/ewo/Account/LoginByPlatform` (field `login_name`, `password`) — đã xác minh endpoint trả về đúng.
- Lưu token / project / mã thiết bị bằng `SharedPreferences`, tự đính kèm header khi gọi API.
- Tầng mạng dùng chung, đọc đúng định dạng trả về `{result, message, data}` của server.

### 40 module, đủ endpoint
Toàn bộ **156 endpoint** được trích từ chính file `libapp.so` của bản Android (không đoán), nằm trong `lib/core/api_paths.dart`.
Mỗi module trong `lib/features/modules/module_registry.dart` trỏ đúng API danh sách thật của nó.

### Màn hình đã làm đầy đủ
- **Đăng nhập** — validate, hiển thị lỗi server trả về, ghi nhớ tên đăng nhập.
- **Trang chủ** — lưới module theo 5 nhóm, icon gốc nhiều màu.
- **Chấm công** — lấy lịch làm việc hôm nay → GPS thật → tính khoảng cách tới cửa hàng → cảnh báo nếu ngoài bán kính → chụp ảnh → upload.
- **Lịch làm việc** — thống kê hôm nay + danh sách kế hoạch.
- **Cửa hàng** — danh sách + tìm kiếm + chi tiết.
- **Thông báo** — danh sách + chi tiết.
- **Tài khoản** — thông tin nhân viên/thiết bị, đăng xuất.

### Các module còn lại
Danh sách + tìm kiếm + trang chi tiết **chạy bằng dữ liệu thật từ server** (dùng chung một khung), nhưng **chưa có form nhập liệu chi tiết từng field** như bản Android (ví dụ form OSA nhập số mặt/số lượng/giá, form Sellin nhập số lượng theo sản phẩm).
Đây là phần còn phải làm tiếp — xem mục 6.

---

## 3. Cách tạo file .ipa (chưa ký)

### Cách A — GitHub Actions (miễn phí, không cần Mac)
1. Tạo repo mới, đẩy toàn bộ thư mục này lên.
2. Vào tab **Actions** → chọn **Build iOS IPA (unsigned)** → **Run workflow**.
3. Máy macOS của GitHub tự chạy (khoảng 10–15 phút), xong tải artifact **AMS-unsigned-ipa**.
4. Giải nén được file `AMS-unsigned.ipa`.

### Cách B — máy Mac có Xcode
```bash
flutter pub get
cd ios && pod install && cd ..
flutter build ios --release --no-codesign
mkdir -p Payload && cp -R build/ios/iphoneos/Runner.app Payload/
zip -r AMS-unsigned.ipa Payload
```

### Ký để cài lên iPhone
Dùng công cụ bạn đã có (Sideloadly / AltStore / TrollStore tuỳ máy):
- Chọn file `AMS-unsigned.ipa` → ký bằng Apple ID thường (miễn phí, hạn 7 ngày) hoặc chứng chỉ riêng.
- Cài xong vào **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** để tin cậy chứng chỉ.

---

## 4. Cấu trúc thư mục

```
lib/
  main.dart                  khởi động, nạp ngôn ngữ + phiên đăng nhập
  core/
    api_client.dart          HTTP client, header token/project/device
    api_paths.dart           156 endpoint thật
    l10n.dart                nạp 41 file ngôn ngữ gốc
    session.dart             lưu phiên, sinh device id
    theme.dart               màu và theme
  features/
    auth/login_page.dart
    home/home_page.dart
    attendance/attendance_page.dart
    dashboard/dashboard_page.dart
    shops/shop_list_page.dart
    notifications/notifications_page.dart
    modules/module_registry.dart      khai báo 40 module
    modules/module_list_page.dart     khung danh sách dùng chung
    modules/record_detail_page.dart
assets/
  locales/vi/*.json          bộ chữ gốc của app (41 file)
  icons/                     icon gốc (menu, extension, kpi...)
  images/                    logo, nền header
.github/workflows/ios-build.yml
```

---

## 5. Vấn đề cần bạn xác nhận

Tài khoản bạn đưa (`ACACY3483` / (mật khẩu bạn đưa)) đã thử đăng nhập trực tiếp lên server:

```
POST https://ewo-id.acacy.vn/api/ewo/Account/LoginByPlatform
{"login_name":"ACACY3483","password":"***"}
→ {"result":"ERROR","message":"Tên đăng nhập hoặc mật khẩu không đúng"}
```

Server trả về **sai tên đăng nhập hoặc mật khẩu** (không phải lỗi định dạng — field đã đúng).
Nên kiểm tra lại: mật khẩu còn đúng không, tài khoản có bị khoá, hay mật khẩu đã đổi.
App vẫn đăng nhập bình thường khi bạn nhập đúng.

---

## 6. Phần làm tiếp (theo thứ tự ưu tiên)

1. Form nhập liệu chi tiết cho các module báo cáo: OSA (số mặt, số lượng, giá, chụp ảnh kệ), Sellin/Sellout (nhập theo sản phẩm), Inventory, Display, OOL, POG, POSM, SOS.
2. Quét barcode + OCR (bản Android dùng MLKit) — trên iOS dùng Vision / ML Kit iOS.
3. Gửi ảnh thật lên `files.acacy.com.vn` (hiện mới gửi metadata).
4. Nhận diện kệ hàng qua `ai-api.acacy.vn` (unime-v3) — cần server của họ bật quyền cho tài khoản.
5. Đồng bộ offline (bản gốc dùng ObjectBox) — hiện chưa có cache offline.
6. Bản đồ số (Google Maps key riêng).

---

## 7. Ghi chú kỹ thuật

- Flutter 3.24.5 / Dart 3.5.4, iOS deployment target 12.0.
- Quyền iOS đã khai trong `ios/Runner/Info.plist`: vị trí, camera, thư viện ảnh, micro.
- `NSAppTransportSecurity → NSAllowsArbitraryLoads = true` để gọi được API; nếu muốn siết bảo mật thì khai domain cụ thể.
- Icon menu giữ nguyên màu gốc (không tint) để giống bản Android.
- Có cờ build `--dart-define=SKIP_LOGIN=true` để xem giao diện mà không cần đăng nhập (chỉ dùng khi test).

---

## 8. Cập nhật 24/11/2026 — đã nối API thật bằng tài khoản thật

Tài khoản test `ACACY3482` đăng nhập OK. Trong lúc test phát hiện và sửa 3 lỗi chặn dữ liệu:

1. **Token bị lặp `Bearer`** — server trả `token` đã có sẵn chữ `Bearer `, client lại ghép thêm lần nữa
   → mọi request sau login đều 401. Đã sửa trong `ApiClient._opts()`.
2. **Thiếu `employee_id` / `project_id`** — server lọc theo id số, bản trước chỉ gửi `employee_code`
   nên nhiều module trả `data: []`. Nay login lưu `employee_id` (data.employee[0].employee_id) và
   `project_id` (data.projects[0].project_id), mọi body dùng `ApiClient.stdBody()`.
3. **Màn Cửa hàng** — chuyển sang đúng endpoint `POST /api/attendance/Prcs/PrcGetStorePermission`
   (body `{employee_id, project_id}` → `data.store_list[]`), có search, refresh, bấm xem chi tiết.

Đã kiểm chứng thật (không đoán):

| Hạng mục | Kết quả |
|---|---|
| `flutter analyze` | 0 error |
| `flutter test` | 3/3 pass |
| `flutter build web --release` | OK |
| Login qua API thật | `Nguyễn Quang Anh / ACACY3482`, emp=10311, prj=42 |
| `PrcGetStorePermission` | 1 shop: `111209 · C004500802 · Mediamart Le Hong Phong` |
| `ewo_ATD_config_Get` | 10 cấu hình chấm công |
| UI thật trên trình duyệt | đăng nhập → tab Cửa hàng hiển thị đúng shop trên |

Endpoint đã xác nhận có dữ liệu với tài khoản này:
`PrcGetStorePermission`, `ewo_ATD_config_Get`, `ewo_ShopTypes_ListbyProject` (236 shop type),
`Prc_ATD_Result` (rỗng — tháng này chưa có bảng công), `notification/get` (rỗng).

Lưu ý: `ewo_ATD_working_plan_GetList` trả rỗng vì tuần này chưa có lịch làm việc được phân;
`Prc_Summary_ATD_Result` đang lỗi phía server (`ObjectDisposedException` của Dapper) — không phải lỗi app.
