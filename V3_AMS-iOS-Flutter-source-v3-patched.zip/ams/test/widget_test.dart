import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:ams/core/l10n.dart';
import 'package:ams/core/theme.dart';
import 'package:ams/features/auth/login_page.dart';
import 'package:ams/features/modules/module_registry.dart';

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  testWidgets('màn hình đăng nhập hiển thị đúng', (tester) async {
    await L.load();
    await tester.pumpWidget(MaterialApp(
      theme: AppTheme.build(),
      home: const LoginPage(),
    ));
    await tester.pumpAndSettle();

    // Nhãn lấy từ bộ ngôn ngữ gốc
    expect(find.text(L.t('login.title.username')), findsWidgets);
    expect(find.text(L.t('login.title.password')), findsWidgets);
    expect(find.text(L.t('login.action.login')), findsOneWidget);
  });

  test('bộ ngôn ngữ nạp đủ khoá của app gốc', () async {
    TestWidgetsFlutterBinding.ensureInitialized();
    await L.load();
    expect(L.t('attendant.title.attendant'), 'Chấm công');
    expect(L.t('work_result.title.osa'), 'Osa');
    expect(L.has('login.action.login'), isTrue);
  });

  test('mọi module đều có endpoint và tiêu đề', () {
    for (final m in kModules) {
      expect(m.listApi.startsWith('/api/'), isTrue, reason: m.code);
      expect(m.iconPath.isNotEmpty, isTrue, reason: m.code);
      expect(m.title.isNotEmpty, isTrue, reason: m.code);
    }
    expect(kModules.length, greaterThanOrEqualTo(30));
  });
}
