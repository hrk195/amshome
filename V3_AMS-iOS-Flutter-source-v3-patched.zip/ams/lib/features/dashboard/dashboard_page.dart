import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/api_client.dart';
import '../../core/api_paths.dart';
import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../attendance/attendance_page.dart';
import '../modules/module_list_page.dart' show extractList;
import '../modules/record_detail_page.dart';

/// Tab "Lịch làm việc": tóm tắt hôm nay + danh sách kế hoạch làm việc.
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<Map<String, dynamic>> _plans = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final res = await ApiClient.I.post(
      ApiPaths.api_attendance_Mobiles_ewo_ATD_working_plan_GetList,
      data: {
        'employee_code': ApiClient.I.employeeCode ?? '',
        'login_name': ApiClient.I.loginName,
        'work_date': today,
        'date_from': today,
        'date_to': today,
      },
    );
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (res.ok) {
        _plans = extractList(res.data);
        _error = _plans.isEmpty && res.message.isNotEmpty ? res.message : null;
      } else {
        _error = res.message.isEmpty ? null : res.message;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final worked = _plans.where((p) {
      final v = p['check_in'] ?? p['time_in'] ?? p['work_time_in'];
      return v != null && v.toString().isNotEmpty;
    }).length;

    return Scaffold(
      appBar: AppBar(
        title: Text(L.t('dashboard.title.timesheet')),
        actions: [
          IconButton(
            onPressed: _load,
            icon: const Icon(Icons.refresh, size: 20),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Row(
              children: [
                Expanded(
                  child: _statCard(
                    Icons.event_available_outlined,
                    '${_plans.length}',
                    'Kế hoạch hôm nay',
                    AppColors.primary,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _statCard(
                    Icons.check_circle_outline,
                    '$worked',
                    L.t('attendant.title.checkin'),
                    AppColors.success,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            SectionCard(
              child: Row(
                children: [
                  const Icon(Icons.today, size: 18, color: AppColors.textSecondary),
                  const SizedBox(width: 8),
                  Text(
                    DateFormat('EEEE, dd/MM/yyyy').format(now),
                    style: const TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const AttendancePage()),
                    ),
                    child: Text(
                      L.t('attendant.title.attendant'),
                      style: const TextStyle(fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.only(left: 2, bottom: 8),
              child: Text(
                L.t('workingPlan.tab.workingPlan'),
                style: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            if (_loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 40),
                child: LoadingView(),
              )
            else if (_plans.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 30),
                child: EmptyView(
                  message: _error ?? L.t('common.msg.no_data'),
                  icon: Icons.event_busy_outlined,
                ),
              )
            else
              ..._plans.map((p) {
                final name = (p['shop_name'] ?? p['shopName'] ?? p['name'] ?? '-')
                    .toString();
                final addr = (p['address'] ?? '').toString();
                final shift =
                    (p['shift_name'] ?? p['shift_code'] ?? '').toString();
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => RecordDetailPage(
                        title: name,
                        moduleTitle: L.t('workingPlan.tab.workingPlan'),
                        data: p,
                      ),
                    )),
                    child: Container(
                      padding: const EdgeInsets.all(13),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: AppColors.primaryLight,
                              borderRadius: BorderRadius.circular(9),
                            ),
                            child: const Icon(Icons.storefront,
                                size: 20, color: AppColors.primary),
                          ),
                          const SizedBox(width: 11),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.textPrimary,
                                    )),
                                if (addr.isNotEmpty || shift.isNotEmpty) ...[
                                  const SizedBox(height: 3),
                                  Text(
                                    [addr, shift]
                                        .where((e) => e.isNotEmpty)
                                        .join(' • '),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontSize: 12.5,
                                        color: AppColors.textSecondary),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_right,
                              size: 20, color: AppColors.textSecondary),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _statCard(IconData icon, String value, String label, Color color) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, size: 26, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    )),
                Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 11.5, color: AppColors.textSecondary)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
