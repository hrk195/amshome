import 'package:flutter/material.dart';
import '../../core/api_client.dart';
import '../../core/api_paths.dart';
import '../../core/l10n.dart';
import '../../core/session.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../home/home_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    Session.loadLoginName().then((v) {
      if (v.isNotEmpty && mounted) setState(() => _user.text = v);
    });
  }

  @override
  void dispose() {
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _doLogin() async {
    final u = _user.text.trim();
    final p = _pass.text;
    if (u.isEmpty) {
      setState(() => _error = L.t('login.error.username'));
      return;
    }
    if (p.isEmpty) {
      setState(() => _error = L.t('login.error.password'));
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });

    final res = await ApiClient.I.post(
      ApiPaths.api_ewo_Account_LoginByPlatform,
      data: {'login_name': u, 'password': p},
    );

    if (!mounted) return;

    if (!res.ok) {
      setState(() {
        _loading = false;
        _error = res.message.isNotEmpty
            ? res.message
            : L.t('login.msg.login_failed_retry', {'code': '${res.statusCode}'});
      });
      return;
    }

    final token = _extractToken(res.data);
    if (token == null || token.isEmpty) {
      setState(() {
        _loading = false;
        _error = L.t('login.msg.login_failed_retry', {'code': 'no-token'});
      });
      return;
    }

    await Session.saveLogin(
      token: token,
      projectCode: _extractProject(res.data),
      employeeCode: _extractEmployeeCode(res.data),
      employeeName: _extractEmployeeName(res.data),
      loginName: u,
      employeeId: _extractEmployeeId(res.data),
      projectId: _extractProjectId(res.data),
    );

    if (!mounted) return;
    setState(() => _loading = false);
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomePage()),
    );
  }

  String? _extractToken(dynamic data) {
    if (data == null) return null;
    if (data is String) return data;
    if (data is Map) {
      for (final k in [
        'token', 'Token', 'access_token', 'accessToken', 'access-token',
        'jwt', 'Jwt', 'bearer', 'Bearer', 'data'
      ]) {
        final v = data[k];
        if (v is String && v.isNotEmpty) return v;
        if (v is Map) {
          final inner = _extractToken(v);
          if (inner != null) return inner;
        }
      }
      // fallback: chuỗi dài trông như JWT
      for (final v in data.values) {
        if (v is String && v.split('.').length == 3 && v.length > 40) return v;
      }
    }
    return null;
  }

  String? _extractProject(dynamic data) {
    if (data is Map) {
      for (final k in ['projectCode', 'ProjectCode', 'project_code', 'project']) {
        final v = data[k];
        if (v is String && v.isNotEmpty) return v;
        if (v is Map) {
          final c = v['code'] ?? v['Code'] ?? v['projectCode'];
          if (c is String && c.isNotEmpty) return c;
        }
      }
    }
    return null;
  }

  String? _extractEmployeeCode(dynamic data) {
    if (data is Map) {
      for (final k in ['employee_code', 'employeeCode', 'EmployeeCode', 'code', 'userName']) {
        final v = data[k];
        if (v is String && v.isNotEmpty) return v;
      }
    }
    return null;
  }

  /// data.employee[0].employee_id — server lọc theo id số này.
  int? _extractEmployeeId(dynamic data) {
    if (data is Map) {
      final emp = data['employee'] ?? data['Employee'];
      if (emp is List && emp.isNotEmpty && emp.first is Map) {
        final v = (emp.first as Map)['employee_id'] ?? (emp.first as Map)['EmployeeId'];
        if (v is int) return v;
        if (v is String) return int.tryParse(v);
      }
      for (final k in ['employee_id', 'employeeId', 'EmployeeId']) {
        final v = data[k];
        if (v is int) return v;
        if (v is String) {
          final p = int.tryParse(v);
          if (p != null) return p;
        }
      }
    }
    return null;
  }

  /// data.projects[0].project_id — dự án mặc định (SAMSUNG).
  int? _extractProjectId(dynamic data) {
    if (data is Map) {
      final prj = data['projects'] ?? data['Projects'];
      if (prj is List && prj.isNotEmpty && prj.first is Map) {
        final v = (prj.first as Map)['project_id'] ?? (prj.first as Map)['ProjectId'];
        if (v is int) return v;
        if (v is String) return int.tryParse(v);
      }
    }
    return null;
  }

  String? _extractEmployeeName(dynamic data) {
    if (data is Map) {
      for (final k in ['employee_name', 'employeeName', 'full_name', 'fullName', 'name']) {
        final v = data[k];
        if (v is String && v.isNotEmpty) return v;
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 56),
              Image.asset('assets/images/logo_full.png', height: 74),
              const SizedBox(height: 26),
              Text(
                'AMS',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  color: AppColors.primary,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'ACACY Workforce Management',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 38),
              AppField(
                label: L.t('login.title.username'),
                controller: _user,
              ),
              const SizedBox(height: 16),
              AppField(
                label: L.t('login.title.password'),
                controller: _pass,
                obscure: _obscure,
                suffix: IconButton(
                  icon: Icon(
                    _obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    size: 20,
                    color: AppColors.textSecondary,
                  ),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
                onChanged: (_) {},
              ),
              if (_error != null) ...[
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFDECEA),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline,
                          size: 18, color: AppColors.danger),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(_error!,
                            style: const TextStyle(
                                fontSize: 13, color: AppColors.danger)),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _loading ? null : _doLogin,
                child: _loading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2.2, color: Colors.white),
                      )
                    : Text(L.t('login.action.login')),
              ),
              const SizedBox(height: 14),
              TextButton(
                onPressed: () => showToast(context, L.t('login.title.forgetPassword')),
                child: Text(
                  L.t('login.title.forgetPassword'),
                  style: const TextStyle(fontSize: 13, color: AppColors.primary),
                ),
              ),
              const SizedBox(height: 40),
              Text(
                '${L.t('login.title.version')} 1.0.3',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
