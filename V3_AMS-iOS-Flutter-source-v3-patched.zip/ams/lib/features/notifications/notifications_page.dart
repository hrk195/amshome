import 'package:flutter/material.dart';
import '../../core/api_client.dart';
import '../../core/api_paths.dart';
import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../modules/module_list_page.dart' show extractList;
import '../modules/record_detail_page.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final res = await ApiClient.I.post(
      ApiPaths.api_notification_notification_get,
      data: {
        'employee_code': ApiClient.I.employeeCode ?? '',
        'login_name': ApiClient.I.loginName,
        'page': 1,
        'page_size': 50,
        'skip': 0,
        'take': 50,
      },
    );
    if (!mounted) return;
    setState(() {
      _loading = false;
      _items = res.ok ? extractList(res.data) : [];
      if (!res.ok || (_items.isEmpty && res.message.isNotEmpty)) {
        _error = res.message.isEmpty ? null : res.message;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(L.t('notifications.title.notifications')),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh, size: 20)),
        ],
      ),
      body: _loading
          ? const LoadingView()
          : _items.isEmpty
              ? EmptyView(
                  message: _error ?? L.t('common.msg.no_data'),
                  icon: Icons.notifications_off_outlined,
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(12),
                    itemCount: _items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) {
                      final n = _items[i];
                      final title = (n['title'] ??
                              n['notify_title'] ??
                              n['name'] ??
                              L.t('notifications.title.notifications'))
                          .toString();
                      final body = (n['content'] ??
                              n['message'] ??
                              n['body'] ??
                              '')
                          .toString();
                      final date = (n['created_date'] ??
                              n['createdDate'] ??
                              n['date'] ??
                              '')
                          .toString();
                      return InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => RecordDetailPage(
                              title: title,
                              moduleTitle: L.t('notifications.title.notifications'),
                              data: n,
                            ),
                          ),
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(13),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 36,
                                height: 36,
                                decoration: BoxDecoration(
                                  color: AppColors.primaryLight,
                                  borderRadius: BorderRadius.circular(9),
                                ),
                                child: const Icon(Icons.notifications,
                                    size: 19, color: AppColors.primary),
                              ),
                              const SizedBox(width: 11),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(title,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.textPrimary,
                                        )),
                                    if (body.isNotEmpty) ...[
                                      const SizedBox(height: 4),
                                      Text(body,
                                          maxLines: 3,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                              fontSize: 12.5,
                                              height: 1.35,
                                              color: AppColors.textSecondary)),
                                    ],
                                    if (date.isNotEmpty) ...[
                                      const SizedBox(height: 6),
                                      Text(date,
                                          style: const TextStyle(
                                              fontSize: 11.5,
                                              color: AppColors.textSecondary)),
                                    ],
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
