import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/api_client.dart';
import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import 'module_registry.dart';
import 'record_detail_page.dart';

/// Trích danh sách bản ghi từ response bất kỳ của server.
/// Server trả nhiều kiểu (data là list, data.items, data.records...) nên phải dò.
List<Map<String, dynamic>> extractList(dynamic data) {
  if (data == null) return [];
  if (data is List) {
    return data.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }
  if (data is Map) {
    for (final k in [
      'items', 'Items', 'records', 'Records', 'list', 'List',
      'rows', 'Rows', 'data', 'Data', 'result', 'Result', 'lst', 'Lst',
      'results', 'Results', 'transactions', 'sessions'
    ]) {
      final v = data[k];
      if (v is List) {
        return v.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      }
      if (v is Map) {
        final inner = extractList(v);
        if (inner.isNotEmpty) return inner;
      }
    }
    // dò sâu: lấy list đầu tiên tìm được
    for (final v in data.values) {
      if (v is List && v.isNotEmpty && v.first is Map) {
        return v.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      }
    }
    // object đơn lẻ vẫn hiển thị được
    if (data.isNotEmpty) return [Map<String, dynamic>.from(data)];
  }
  return [];
}

class ModuleListPage extends StatefulWidget {
  final ModuleDef module;
  final Map<String, dynamic>? extraParams;

  const ModuleListPage({super.key, required this.module, this.extraParams});

  @override
  State<ModuleListPage> createState() => _ModuleListPageState();
}

class _ModuleListPageState extends State<ModuleListPage> {
  final _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _all = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_applyFilter);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Map<String, dynamic> _body() {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final from = DateFormat('yyyy-MM-dd')
        .format(DateTime.now().subtract(const Duration(days: 30)));
    return ApiClient.I.stdBody({
      'work_date': today,
      'date_from': from,
      'date_to': today,
      'from_date': from,
      'to_date': today,
      'page': 1,
      'page_size': 100,
      'pageSize': 100,
      'skip': 0,
      'take': 100,
      ...?widget.extraParams,
    });
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final res = await ApiClient.I.post(widget.module.listApi, data: _body());
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (res.ok) {
        _all = extractList(res.data);
        _filtered = _all;
        if (_all.isEmpty && res.message.isNotEmpty) _error = res.message;
      } else {
        _all = [];
        _filtered = [];
        _error = res.message.isEmpty
            ? L.t('common.msg.no_data')
            : res.message;
      }
    });
  }

  void _applyFilter() {
    final q = _searchCtrl.text.trim().toLowerCase();
    setState(() {
      if (q.isEmpty) {
        _filtered = _all;
      } else {
        _filtered = _all.where((e) {
          return e.values.any((v) => v.toString().toLowerCase().contains(q));
        }).toList();
      }
    });
  }

  String _primaryOf(Map<String, dynamic> item) {
    for (final k in widget.module.primaryKeys) {
      final v = item[k];
      if (v != null && v.toString().trim().isNotEmpty) return v.toString();
    }
    // fallback: giá trị chuỗi đầu tiên
    for (final v in item.values) {
      if (v is String && v.trim().isNotEmpty) return v;
    }
    return '-';
  }

  String _secondaryOf(Map<String, dynamic> item, String skip) {
    final parts = <String>[];
    for (final k in widget.module.secondaryKeys) {
      final v = item[k];
      if (v == null) continue;
      final s = v.toString().trim();
      if (s.isEmpty || s == skip) continue;
      parts.add(s);
      if (parts.length >= 2) break;
    }
    return parts.join(' • ');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.module.title),
        actions: [
          IconButton(
            onPressed: _load,
            icon: const Icon(Icons.refresh),
            tooltip: L.t('dashboard.title.retry'),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: L.t('common.msg.no_item_selected') == ''
                    ? 'Tìm kiếm'
                    : L.t('process.title.search.hint'),
                prefixIcon: const Icon(Icons.search, size: 20),
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return LoadingView(message: L.t('common.title.loading_photo'));
    }
    if (_error != null) {
      return Column(
        children: [
          Expanded(
            child: EmptyView(
              message: _error!,
              icon: Icons.cloud_off_outlined,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _load,
                child: Text(L.t('dashboard.title.retry')),
              ),
            ),
          ),
        ],
      );
    }
    if (_filtered.isEmpty) {
      return EmptyView(message: L.t('common.msg.no_data'));
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: _filtered.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final item = _filtered[i];
          final primary = _primaryOf(item);
          final secondary = _secondaryOf(item, primary);
          return InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => RecordDetailPage(
                title: primary,
                moduleTitle: widget.module.title,
                data: item,
              ),
            )),
            child: Container(
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: AppSvgIcon(widget.module.iconPath,
                        size: 22, tint: AppColors.primary),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          primary,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        if (secondary.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(
                            secondary,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 12.5,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right,
                      size: 20, color: AppColors.textSecondary),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
