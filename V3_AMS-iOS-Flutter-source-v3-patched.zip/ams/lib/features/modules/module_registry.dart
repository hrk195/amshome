import '../../core/api_paths.dart';
import '../../core/l10n.dart';

/// Một module trong app. Toàn bộ tiêu đề lấy từ bộ ngôn ngữ gốc,
/// endpoint lấy từ chính bản Android nên khớp với server thật.
class ModuleDef {
  final String code;
  final String titleKey;
  final String? fallbackTitle;
  final String iconPath;
  final String listApi;
  final String group;
  final List<String> primaryKeys;
  final List<String> secondaryKeys;

  const ModuleDef({
    required this.code,
    required this.titleKey,
    this.fallbackTitle,
    required this.iconPath,
    required this.listApi,
    required this.group,
    this.primaryKeys = const [
      'shop_name', 'shopName', 'product_name', 'productName',
      'full_name', 'name', 'title', 'code_name', 'code'
    ],
    this.secondaryKeys = const [
      'address', 'shop_code', 'work_date', 'created_date', 'code', 'status_name'
    ],
  });

  String get title {
    final t = L.t(titleKey);
    if (t == titleKey && fallbackTitle != null) return fallbackTitle!;
    return t;
  }
}

const _menu = 'assets/icons/menu/';

const List<ModuleDef> kModules = [
  // ── Công việc hằng ngày ───────────────────────────────────────────────
  ModuleDef(
    code: 'attendance',
    titleKey: 'work_result.title.attendant',
    iconPath: '${_menu}timesheet.svg',
    listApi: ApiPaths.api_attendance_Mobiles_ewo_ATD_working_plan_GetList,
    group: 'daily',
    primaryKeys: ['shop_name', 'shopName', 'name', 'shop_code'],
    secondaryKeys: ['address', 'shift_name', 'work_date', 'work_time_in'],
  ),
  ModuleDef(
    code: 'working_plan',
    titleKey: 'workingPlan.tab.workingPlan',
    iconPath: '${_menu}timesheet.svg',
    listApi: ApiPaths.api_attendance_Mobiles_ewo_ATD_working_plan_GetList,
    group: 'daily',
    primaryKeys: ['shop_name', 'shopName', 'name', 'work_date'],
    secondaryKeys: ['address', 'shift_name', 'work_date'],
  ),
  ModuleDef(
    code: 'shops',
    titleKey: 'attendant.title.title.shop',
    iconPath: '${_menu}store.svg',
    listApi: ApiPaths.api_ewo_Shops_ewo_GetShopRouter,
    group: 'daily',
    primaryKeys: ['shop_name', 'shopName', 'name', 'shop_code'],
    secondaryKeys: ['address', 'shop_type_name', 'shop_code'],
  ),
  ModuleDef(
    code: 'notifications',
    titleKey: 'notifications.title.notifications',
    iconPath: '${_menu}approve_request.svg',
    listApi: ApiPaths.api_notification_notification_get,
    group: 'daily',
    primaryKeys: ['title', 'notify_title', 'content', 'message', 'name'],
    secondaryKeys: ['created_date', 'createdDate', 'date', 'body', 'content'],
  ),

  // ── Thị trường & bán hàng ─────────────────────────────────────────────
  ModuleDef(
    code: 'osa',
    titleKey: 'work_result.title.osa',
    iconPath: '${_menu}check_product.svg',
    listApi: ApiPaths.api_osa_OSA_OSA_result_GetItem,
    group: 'sales',
    primaryKeys: ['product_name', 'productName', 'name', 'code_name'],
    secondaryKeys: ['shop_name', 'quantity', 'facing', 'work_date'],
  ),
  ModuleDef(
    code: 'sellin',
    titleKey: 'work_result.title.sellin',
    iconPath: '${_menu}shop_report.svg',
    listApi: ApiPaths.api_sell_SellIns_SellIn_Result_GetList,
    group: 'sales',
  ),
  ModuleDef(
    code: 'sellout',
    titleKey: 'work_result.title.sellout',
    iconPath: '${_menu}shop_report.svg',
    listApi: ApiPaths.api_sell_SellOuts_SellOut_Result_GetList,
    group: 'sales',
  ),
  ModuleDef(
    code: 'inventory',
    titleKey: 'work_result.title.inventory',
    iconPath: '${_menu}check_product.svg',
    listApi: ApiPaths.api_inventory_Inven_Results_GetList,
    group: 'sales',
  ),
  ModuleDef(
    code: 'inventory_tracking',
    titleKey: 'work_result.title.inventory_tracking',
    iconPath: '${_menu}statistics.svg',
    listApi: ApiPaths.api_inventory_Mobiles_GetInventoryShop,
    group: 'sales',
  ),
  ModuleDef(
    code: 'display',
    titleKey: 'work_result.title.display',
    iconPath: '${_menu}shop_visit.svg',
    listApi: ApiPaths.api_display_Display_Promotion_result_GetList,
    group: 'sales',
  ),
  ModuleDef(
    code: 'ool',
    titleKey: 'work_result.title.ool',
    iconPath: '${_menu}check_product.svg',
    listApi: ApiPaths.api_ool_OOL_OOL_Results_GetList,
    group: 'sales',
  ),
  ModuleDef(
    code: 'pog',
    titleKey: 'work_result.title.pog',
    iconPath: '${_menu}shop_visit.svg',
    listApi: ApiPaths.api_pog_PogTarget_report_detail,
    group: 'sales',
  ),
  ModuleDef(
    code: 'posm',
    titleKey: 'work_result.title.posm',
    iconPath: '${_menu}shop_visit.svg',
    listApi: ApiPaths.api_posm_POSM_POSM_results_GetItem,
    group: 'sales',
  ),
  ModuleDef(
    code: 'sos',
    titleKey: 'download.title.sos_report',
    iconPath: '${_menu}tool.svg',
    listApi: ApiPaths.api_sos_SOS_Results_GetList,
    group: 'sales',
  ),
  ModuleDef(
    code: 'rpm_tracking',
    titleKey: 'work_result.title.rpm_tracking',
    iconPath: '${_menu}statistics.svg',
    listApi: ApiPaths.api_display_Mobiles_Mobile_GetPromotionDisplay,
    group: 'sales',
  ),

  // ── Báo cáo & KPI ─────────────────────────────────────────────────────
  ModuleDef(
    code: 'dashboard',
    titleKey: 'dashboard.title.summary',
    fallbackTitle: 'Tổng hợp',
    iconPath: '${_menu}statistics.svg',
    listApi: ApiPaths.api_attendance_Prcs_Prc_Summary_ATD_Result,
    group: 'report',
    primaryKeys: ['employee_name', 'full_name', 'name', 'code'],
    secondaryKeys: ['total', 'work_date', 'created_date', 'status_name'],
  ),
  ModuleDef(
    code: 'report_summary',
    titleKey: 'download.title.kpi_config',
    iconPath: '${_menu}kpi.svg',
    listApi: ApiPaths.api_attendance_Prcs_Prc_Summary_ATD_Result,
    group: 'report',
  ),
  ModuleDef(
    code: 'work_result',
    titleKey: 'work_result.title.sellout',
    iconPath: '${_menu}shop_report.svg',
    listApi: ApiPaths.api_attendance_Mobiles_MOBILE_Attendace_GetItemResult,
    group: 'report',
  ),
  ModuleDef(
    code: 'process',
    titleKey: 'process.title.process',
    iconPath: '${_menu}view_request.svg',
    listApi: ApiPaths.api_attendance_Prcs_Prc_ProjectGetRequest,
    group: 'report',
    primaryKeys: ['title', 'content', 'request_type_name', 'code'],
    secondaryKeys: ['created_date', 'status_name', 'employee_name'],
  ),

  // ── Khảo sát & thị trường ─────────────────────────────────────────────
  ModuleDef(
    code: 'survey',
    titleKey: 'download.title.survey_report',
    iconPath: '${_menu}quick_test.svg',
    listApi: ApiPaths.api_survey_Survey_ewo_GetSurveyList,
    group: 'market',
  ),
  ModuleDef(
    code: 'market_information',
    titleKey: 'work_result.title.market_information',
    iconPath: '${_menu}distribution.svg',
    listApi: ApiPaths.api_survey_Survey_ewo_GetSurveyList,
    group: 'market',
  ),
  ModuleDef(
    code: 'quick_test',
    titleKey: 'quick.test.title.quick.test',
    iconPath: '${_menu}quick_test.svg',
    listApi: ApiPaths.api_survey_QuickTest_Mobile_EmployeeGetQuickTestBySurvey_History,
    group: 'market',
    primaryKeys: ['survey_name', 'name', 'title', 'code'],
    secondaryKeys: ['created_date', 'score', 'status_name'],
  ),
  ModuleDef(
    code: 'digital_map',
    titleKey: 'digital_map.title.digital_map',
    fallbackTitle: 'Bản đồ số',
    iconPath: '${_menu}digital_map.svg',
    listApi: ApiPaths.api_maps_loadmarkers,
    group: 'market',
    primaryKeys: ['shop_name', 'name', 'shopName'],
    secondaryKeys: ['address', 'latitude', 'longitude'],
  ),
  ModuleDef(
    code: 'coaching',
    titleKey: 'work_result.title.field_coaching',
    iconPath: '${_menu}field_coaching.svg',
    listApi: ApiPaths.api_fieldcoaching_FieldCoaching_GetFieldCoaching,
    group: 'market',
  ),

  // ── Quản lý & khác ────────────────────────────────────────────────────
  ModuleDef(
    code: 'create_shop',
    titleKey: 'create.shop.title.create.shop',
    iconPath: '${_menu}store.svg',
    listApi: ApiPaths.api_ewo_Shops_ewo_ShopTypes_ListbyProject,
    group: 'manage',
    primaryKeys: ['name', 'shop_type_name', 'code'],
    secondaryKeys: ['code', 'description'],
  ),
  ModuleDef(
    code: 'activation',
    titleKey: 'work_result.title.activation',
    iconPath: '${_menu}target.svg',
    listApi: ApiPaths.api_activation_Activation_Works_GetList,
    group: 'manage',
  ),
  ModuleDef(
    code: 'document',
    titleKey: 'document.title.list.document',
    iconPath: '${_menu}document.svg',
    listApi: ApiPaths.api_ewo_Masters_ewo_Masters_GetList,
    group: 'manage',
    primaryKeys: ['title', 'name', 'file_name', 'code'],
    secondaryKeys: ['created_date', 'description', 'code'],
  ),
  ModuleDef(
    code: 'products',
    titleKey: 'common.title.select_product',
    iconPath: '${_menu}check_product.svg',
    listApi: ApiPaths.api_ewo_Product_ewo_Products_GetList,
    group: 'manage',
    primaryKeys: ['product_name', 'productName', 'name', 'code_name'],
    secondaryKeys: ['product_code', 'category_name', 'unit'],
  ),
  ModuleDef(
    code: 'training',
    titleKey: 'training.title.training',
    fallbackTitle: 'Đào tạo',
    iconPath: '${_menu}training.svg',
    listApi: ApiPaths.api_ewo_Masters_ewo_Masters_GetList,
    group: 'manage',
  ),
  ModuleDef(
    code: 'upload',
    titleKey: 'upload.title.upload',
    fallbackTitle: 'Đồng bộ dữ liệu',
    iconPath: '${_menu}upload.svg',
    listApi: ApiPaths.api_ewo_Logs_ewo_Logfile_Create,
    group: 'manage',
  ),
  ModuleDef(
    code: 'transaction',
    titleKey: 'transaction.title.transaction',
    fallbackTitle: 'Giao dịch AI',
    iconPath: '${_menu}check_product.svg',
    listApi: ApiPaths.api_ai_v3_unime_v3_detection_transaction_sessions,
    group: 'manage',
    primaryKeys: ['shop_name', 'name', 'session_id'],
    secondaryKeys: ['created_date', 'status', 'total'],
  ),
];

const Map<String, String> kGroupTitles = {
  'daily': 'Công việc hằng ngày',
  'sales': 'Thị trường & bán hàng',
  'report': 'Báo cáo & KPI',
  'market': 'Khảo sát & thị trường',
  'manage': 'Quản lý & khác',
};

/// Module hiện trên lưới menu trang chủ.
final List<ModuleDef> kHomeModules =
    kModules.where((m) => m.code != 'work_result').toList();
