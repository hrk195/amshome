import 'package:flutter/material.dart';
import '../../core/theme.dart';

/// Trang chi tiết 1 bản ghi: hiển thị đầy đủ field server trả về,
/// bỏ qua field rỗng, field lồng nhau thì hiển thị dạng JSON gọn.
class RecordDetailPage extends StatelessWidget {
  final String title;
  final String moduleTitle;
  final Map<String, dynamic> data;

  const RecordDetailPage({
    super.key,
    required this.title,
    required this.moduleTitle,
    required this.data,
  });

  String _label(String key) {
    final s = key
        .replaceAll('_', ' ')
        .replaceAllMapped(RegExp(r'([a-z])([A-Z])'), (m) => '${m[1]} ${m[2]}');
    if (s.isEmpty) return key;
    return s[0].toUpperCase() + s.substring(1);
  }

  String _value(dynamic v) {
    if (v == null) return '';
    if (v is Map || v is List) return v.toString();
    if (v is bool) return v ? 'Có' : 'Không';
    return v.toString();
  }

  @override
  Widget build(BuildContext context) {
    final entries = data.entries
        .where((e) => _value(e.value).trim().isNotEmpty)
        .toList();

    return Scaffold(
      appBar: AppBar(title: Text(moduleTitle)),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '${entries.length} thông tin',
                  style: const TextStyle(
                      fontSize: 12.5, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: Column(
              children: [
                for (final e in entries) ...[
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 125,
                          child: Text(
                            _label(e.key),
                            style: const TextStyle(
                              fontSize: 13,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            _value(e.value),
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (e != entries.last) const Divider(height: 1),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
