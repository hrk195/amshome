import 'package:flutter/material.dart';
import '../../core/api_client.dart';
import '../../core/l10n.dart';
import '../../core/session.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../attendance/attendance_page.dart';
import '../auth/login_page.dart';
import '../dashboard/dashboard_page.dart';
import '../modules/module_list_page.dart';
import '../modules/module_registry.dart';
import '../notifications/notifications_page.dart';
import '../shops/shop_list_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _HomeTab(onOpen: _openModule),
      const DashboardPage(),
      const NotificationsPage(),
      const _AccountTab(),
    ];

    return Scaffold(
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.textSecondary,
        selectedFontSize: 11.5,
        unselectedFontSize: 11.5,
        items: [
          BottomNavigationBarItem(
            icon: const Icon(Icons.home_outlined),
            activeIcon: const Icon(Icons.home),
            label: L.t('dashboard.title.dashboard'),
          ),
          BottomNavigationBarItem(
            icon: const Icon(Icons.event_note_outlined),
            activeIcon: const Icon(Icons.event_note),
            label: L.t('dashboard.title.timesheet'),
          ),
          BottomNavigationBarItem(
            icon: const Icon(Icons.notifications_none),
            activeIcon: const Icon(Icons.notifications),
            label: L.t('notifications.title.notifications'),
          ),
          BottomNavigationBarItem(
            icon: const Icon(Icons.person_outline),
            activeIcon: const Icon(Icons.person),
            label: L.t('dashboard.account.title.account'),
          ),
        ],
      ),
    );
  }

  void _openModule(ModuleDef m) {
    if (m.code == 'attendance') {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const AttendancePage()),
      );
      return;
    }
    if (m.code == 'shops') {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const ShopListPage()),
      );
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ModuleListPage(module: m)),
    );
  }
}

class _HomeTab extends StatelessWidget {
  final void Function(ModuleDef) onOpen;
  const _HomeTab({required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final groups = <String, List<ModuleDef>>{};
    for (final m in kHomeModules) {
      groups.putIfAbsent(m.group, () => []).add(m);
    }

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 150,
          pinned: true,
          backgroundColor: AppColors.primary,
          title: Text(L.t('dashboard.title.dashboard')),
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/images/background_header.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) =>
                      Container(color: AppColors.primary),
                ),
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Color(0x22000000), Color(0xCC0B7EBA)],
                    ),
                  ),
                ),
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: 16,
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(22),
                        ),
                        child: const Icon(Icons.person,
                            color: AppColors.primary, size: 26),
                      ),
                      const SizedBox(width: 11),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              ApiClient.I.employeeName ??
                                  (ApiClient.I.loginName ?? '-'),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15.5,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              ApiClient.I.employeeCode ??
                                  (ApiClient.I.loginName ?? '-'),
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 12.5),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        for (final entry in groups.entries) ...[
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
              child: Text(
                kGroupTitles[entry.key] ?? entry.key,
                style: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 4,
                crossAxisSpacing: 2,
                childAspectRatio: 0.82,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, i) {
                  final m = entry.value[i];
                  return InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: () => onOpen(m),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0x0D000000),
                                blurRadius: 6,
                                offset: Offset(0, 2),
                              )
                            ],
                          ),
                          child: Center(
                            child: AppSvgIcon(m.iconPath, size: 28),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          child: Text(
                            m.title,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 11.5,
                              height: 1.15,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
                childCount: entry.value.length,
              ),
            ),
          ),
        ],
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
      ],
    );
  }
}

class _AccountTab extends StatelessWidget {
  const _AccountTab();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(L.t('dashboard.account.title.account'))),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          SectionCard(
            title: L.t('dashboard.account.title.account.information'),
            child: Column(
              children: [
                KvRow('Tên đăng nhập', ApiClient.I.loginName ?? '-'),
                KvRow('Mã nhân viên', ApiClient.I.employeeCode ?? '-'),
                KvRow('Họ tên', ApiClient.I.employeeName ?? '-'),
                KvRow('Dự án', ApiClient.I.projectCode ?? '-'),
                KvRow('Mã thiết bị', ApiClient.I.deviceId ?? '-'),
              ],
            ),
          ),
          const SizedBox(height: 10),
          SectionCard(
            title: L.t('dashboard.tool.title.tool'),
            child: Column(
              children: [
                KvRow('Phiên bản', '1.0.3 (iOS)'),
                KvRow('Nền tảng', 'iOS / Flutter'),
                KvRow('Máy chủ', 'ewo-id.acacy.vn'),
              ],
            ),
          ),
          const SizedBox(height: 18),
          OutlinedButton.icon(
            onPressed: () async {
              await Session.logout();
              if (!context.mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (_) => false,
              );
            },
            icon: const Icon(Icons.logout, size: 18),
            label: Text(L.t('login.action.logout')),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.danger,
              side: const BorderSide(color: AppColors.danger),
              minimumSize: const Size.fromHeight(46),
            ),
          ),
        ],
      ),
    );
  }
}
