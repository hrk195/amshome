import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../../core/api_client.dart';
import '../../core/api_paths.dart';
import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../modules/module_list_page.dart' show extractList;

/// Chấm công: lấy lịch làm việc hôm nay -> chọn cửa hàng -> kiểm tra khoảng cách
/// -> chụp ảnh -> upload. Logic bám theo đúng luồng bản Android.
class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key});

  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  List<Map<String, dynamic>> _plans = [];
  bool _loading = true;
  String? _error;
  Position? _pos;
  String? _gpsError;

  @override
  void initState() {
    super.initState();
    _loadPlans();
    _locate();
  }

  Future<void> _locate() async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() =>
              _gpsError = L.t('attendant.title.msg.waiting.for.find.your.position'));
        }
        return;
      }
      final p = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 25),
      );
      if (mounted) {
        setState(() {
          _pos = p;
          _gpsError = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() =>
            _gpsError = L.t('attendant.title.msg.waiting.for.find.your.position'));
      }
    }
  }

  Future<void> _loadPlans() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final res = await ApiClient.I.post(
      ApiPaths.api_attendance_Mobiles_ewo_ATD_working_plan_GetList,
      data: ApiClient.I.stdBody({
        'login_name': ApiClient.I.loginName,
        'work_date': today,
        'date_from': today,
        'date_to': today,
        'from_date': today,
        'to_date': today,
      }),
    );
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (res.ok) {
        _plans = extractList(res.data);
        if (_plans.isEmpty) _error = res.message.isEmpty ? null : res.message;
      } else {
        _error = res.message.isEmpty ? null : res.message;
      }
    });
  }

  double? _distanceTo(Map<String, dynamic> plan) {
    if (_pos == null) return null;
    final lat = double.tryParse(
        '${plan['latitude'] ?? plan['shop_latitude'] ?? plan['lat'] ?? ''}');
    final lng = double.tryParse(
        '${plan['longitude'] ?? plan['shop_longitude'] ?? plan['lng'] ?? ''}');
    if (lat == null || lng == null) return null;
    final d = Geolocator.distanceBetween(
        _pos!.latitude, _pos!.longitude, lat, lng);
    return d;
  }

  String _distText(double? d) {
    if (d == null) return '-';
    if (d < 1000) return '${d.toStringAsFixed(0)} m';
    return '${(d / 1000).toStringAsFixed(2)} km';
  }

  Future<void> _checkIn(Map<String, dynamic> plan, bool isCheckIn) async {
    final dist = _distanceTo(plan);
    final radius = double.tryParse(
            '${plan['radius'] ?? plan['shop_radius'] ?? plan['ban_kinh'] ?? ''}') ??
        100;

    if (dist != null && dist > radius) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(L.t('attendant.title.check.position')),
          content: Text(L.t(
            'attendant.msg.warning.location.away.store.confirm.attendance',
            {'distance': _distText(dist)},
          )),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(L.t('attendant.title.no')),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(L.t('attendant.title.yes')),
            ),
          ],
        ),
      );
      if (ok != true) return;
    }

    final picker = ImagePicker();
    final XFile? photo = await picker.pickImage(
      source: ImageSource.camera,
      preferredCameraDevice: CameraDevice.front,
      imageQuality: 70,
      maxWidth: 1440,
    );
    if (photo == null) return;

    if (!mounted) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(L.t('attendant.title.check.image.attendance')),
        content: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.file(File(photo.path), height: 220, fit: BoxFit.cover),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(L.t('attendant.title.no')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(L.t('attendant.title.yes')),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    setState(() => _loading = true);
    final res = await ApiClient.I.post(
      ApiPaths.api_attendance_Mobiles_attendance_upload_byshift,
      data: ApiClient.I.stdBody({
        'login_name': ApiClient.I.loginName,
        'shop_code': plan['shop_code'] ?? plan['shopCode'] ?? '',
        'shift_code': plan['shift_code'] ?? plan['shiftCode'] ?? '',
        'work_date': DateFormat('yyyy-MM-dd').format(DateTime.now()),
        'check_type': isCheckIn ? 'IN' : 'OUT',
        'latitude': _pos?.latitude,
        'longitude': _pos?.longitude,
        'distance': dist,
        'image_name': photo.name,
      }),
    );
    if (!mounted) return;
    setState(() => _loading = false);
    showToast(
      context,
      res.ok
          ? L.t('common.action.complete')
          : (res.message.isEmpty ? L.t('attendant.msg.save.image.failed') : res.message),
    );
    if (res.ok) _loadPlans();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(L.t('attendant.title.attendant')),
        actions: [
          IconButton(
            onPressed: () {
              _locate();
              _loadPlans();
            },
            icon: const Icon(Icons.my_location, size: 20),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(
                  _pos != null ? Icons.gps_fixed : Icons.gps_off,
                  size: 18,
                  color: _pos != null ? AppColors.success : AppColors.warning,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _pos != null
                        ? '${L.t('attendant.title.your.coordinates')} '
                            '${_pos!.latitude.toStringAsFixed(6)}, ${_pos!.longitude.toStringAsFixed(6)}'
                        : (_gpsError ??
                            L.t('attendant.title.msg.waiting.for.find.your.position')),
                    style: const TextStyle(
                        fontSize: 12.5, color: AppColors.textSecondary),
                  ),
                ),
              ],
            ),
          ),
          Expanded(child: _buildList()),
        ],
      ),
    );
  }

  Widget _buildList() {
    if (_loading) return LoadingView(message: L.t('common.msg.checking_input'));
    if (_plans.isEmpty) {
      return EmptyView(
        message: _error ?? L.t('common.msg.no_data'),
        icon: Icons.event_busy_outlined,
      );
    }
    return RefreshIndicator(
      onRefresh: _loadPlans,
      child: ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: _plans.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          final p = _plans[i];
          final dist = _distanceTo(p);
          final name = (p['shop_name'] ??
                  p['shopName'] ??
                  p['name'] ??
                  L.t('common.title.unknown'))
              .toString();
          final addr = (p['address'] ?? '').toString();
          final shift = (p['shift_name'] ?? p['shiftName'] ?? p['shift_code'] ?? '')
              .toString();

          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.all(13),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        name,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                    Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppColors.primaryLight,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        _distText(dist),
                        style: const TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w600,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                  ],
                ),
                if (addr.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(addr,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 12.5, color: AppColors.textSecondary)),
                ],
                if (shift.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.schedule,
                          size: 14, color: AppColors.textSecondary),
                      const SizedBox(width: 4),
                      Text(L.t('attendant.title.shift.name', {'name': shift}),
                          style: const TextStyle(
                              fontSize: 12.5, color: AppColors.textSecondary)),
                    ],
                  ),
                ],
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _checkIn(p, true),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.success,
                          side: const BorderSide(color: AppColors.success),
                          minimumSize: const Size.fromHeight(42),
                        ),
                        child: Text(L.t('attendant.title.checkin')),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _checkIn(p, false),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.warning,
                          side: const BorderSide(color: AppColors.warning),
                          minimumSize: const Size.fromHeight(42),
                        ),
                        child: Text(L.t('attendant.title.checkout')),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
