import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

class ApiResponse {
  final bool ok;
  final String message;
  final dynamic data;
  final int statusCode;

  ApiResponse({
    required this.ok,
    required this.message,
    required this.data,
    required this.statusCode,
  });

  factory ApiResponse.fromJson(dynamic body, int code) {
    if (body is Map) {
      final result = (body['result'] ?? body['Result'] ?? '').toString();
      final msg = (body['message'] ?? body['Message'] ?? '').toString();
      final ok = result.toUpperCase() == 'SUCCESS' ||
          result.toUpperCase() == 'OK' ||
          result == '1' ||
          (result.isEmpty && code >= 200 && code < 300);
      return ApiResponse(
        ok: ok,
        message: msg,
        data: body['data'] ?? body['Data'],
        statusCode: code,
      );
    }
    return ApiResponse(
      ok: code >= 200 && code < 300,
      message: '',
      data: body,
      statusCode: code,
    );
  }
}

/// Http client dùng chung cho toàn app.
/// Token / project / device được inject tự động giống bản Android.
class ApiClient {
  ApiClient._();
  static final ApiClient I = ApiClient._();

  static const String baseUrl = 'https://ewo-id.acacy.vn';
  static const String aiBaseUrl = 'https://ai-api.acacy.vn';
  static const String mapsBaseUrl = 'https://maps-api.acacy.vn';

  String? token;
  String? projectCode;
  String? deviceId;
  String? employeeCode;
  String? employeeName;
  String? loginName;
  int? employeeId;
  int? projectId;

  /// Body chuẩn mà bản Android gửi: server lọc theo id số, không phải code.
  Map<String, dynamic> stdBody([Map<String, dynamic>? extra]) => {
        'employee_id': employeeId,
        'project_id': projectId,
        'employee_code': employeeCode ?? '',
        'login_name': loginName ?? '',
        'project_code': projectCode ?? '',
        ...?extra,
      };

  late final Dio _dio = Dio(BaseOptions(
    baseUrl: baseUrl,
    connectTimeout: const Duration(seconds: 25),
    receiveTimeout: const Duration(seconds: 40),
    sendTimeout: const Duration(seconds: 40),
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'User-Agent': 'AMS-iOS/1.0.3 (Flutter)',
    },
    validateStatus: (_) => true,
  ));

  Dio get dio => _dio;

  Options _opts() {
    final h = <String, dynamic>{};
    if (token != null && token!.isNotEmpty) {
      // Server trả token đã kèm sẵn "Bearer " -> không ghép thêm lần nữa.
      h['Authorization'] =
          token!.startsWith('Bearer ') ? token! : 'Bearer $token';
    }
    if (projectCode != null && projectCode!.isNotEmpty) {
      h['ProjectCode'] = projectCode;
    }
    if (deviceId != null && deviceId!.isNotEmpty) {
      h['DeviceId'] = deviceId;
      h['DeviceID'] = deviceId;
    }
    return Options(headers: h);
  }

  Future<ApiResponse> post(String path, {Object? data}) async {
    try {
      final r = await _dio.post(path, data: data ?? {}, options: _opts());
      return ApiResponse.fromJson(r.data, r.statusCode ?? 200);
    } on DioException catch (e) {
      debugPrint('POST $path failed: ${e.type} ${e.message}');
      return ApiResponse(
        ok: false,
        message: e.message ?? 'network error',
        data: e.response?.data,
        statusCode: e.response?.statusCode ?? 0,
      );
    }
  }

  Future<ApiResponse> get(String path, {Map<String, dynamic>? query}) async {
    try {
      final r = await _dio.get(path, queryParameters: query, options: _opts());
      return ApiResponse.fromJson(r.data, r.statusCode ?? 200);
    } on DioException catch (e) {
      return ApiResponse(
        ok: false,
        message: e.message ?? 'network error',
        data: e.response?.data,
        statusCode: e.response?.statusCode ?? 0,
      );
    }
  }

  Future<ApiResponse> postAbsolute(String url, {Object? data}) =>
      post(url.replaceFirst(baseUrl, ''), data: data);

  void clear() {
    token = null;
    projectCode = null;
    employeeCode = null;
    employeeName = null;
    employeeId = null;
    projectId = null;
  }
}
