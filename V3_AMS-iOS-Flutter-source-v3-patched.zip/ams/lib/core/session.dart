import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_client.dart';

/// Lưu phiên đăng nhập + thông tin thiết bị (giống SharedPreferences bản Android).
class Session {
  static const _kToken = 'ewo_token';
  static const _kProject = 'ewo_project';
  static const _kDevice = 'ewo_device_id';
  static const _kEmployee = 'ewo_employee';
  static const _kEmployeeName = 'ewo_employee_name';
  static const _kLoginName = 'ewo_login_name';
  static const _kEmployeeId = 'ewo_employee_id';
  static const _kProjectId = 'ewo_project_id';

  static Future<void> init() async {
    final sp = await SharedPreferences.getInstance();
    ApiClient.I.token = sp.getString(_kToken);
    ApiClient.I.projectCode = sp.getString(_kProject);
    ApiClient.I.employeeCode = sp.getString(_kEmployee);
    ApiClient.I.employeeName = sp.getString(_kEmployeeName);
    ApiClient.I.loginName = sp.getString(_kLoginName);
    _cachedLoginName = sp.getString(_kLoginName);
    ApiClient.I.employeeId = sp.getInt(_kEmployeeId);
    ApiClient.I.projectId = sp.getInt(_kProjectId);

    var dev = sp.getString(_kDevice);
    if (dev == null || dev.isEmpty) {
      dev = _newDeviceId();
      await sp.setString(_kDevice, dev);
    }
    ApiClient.I.deviceId = dev;
  }

  static String _newDeviceId() {
    const chars = '0123456789abcdef';
    final rnd = Random.secure();
    return List.generate(16, (_) => chars[rnd.nextInt(16)]).join();
  }

  static bool get isLoggedIn =>
      ApiClient.I.token != null && ApiClient.I.token!.isNotEmpty;

  static String get loginName {
    return _cachedLoginName ?? '';
  }

  static String? _cachedLoginName;

  static Future<void> saveLogin({
    required String token,
    String? projectCode,
    String? employeeCode,
    String? employeeName,
    String? loginName,
    int? employeeId,
    int? projectId,
  }) async {
    final sp = await SharedPreferences.getInstance();
    ApiClient.I.token = token;
    await sp.setString(_kToken, token);
    if (projectCode != null) {
      ApiClient.I.projectCode = projectCode;
      await sp.setString(_kProject, projectCode);
    }
    if (employeeCode != null) {
      ApiClient.I.employeeCode = employeeCode;
      await sp.setString(_kEmployee, employeeCode);
    }
    if (employeeName != null) {
      ApiClient.I.employeeName = employeeName;
      await sp.setString(_kEmployeeName, employeeName);
    }
    if (employeeId != null) {
      ApiClient.I.employeeId = employeeId;
      await sp.setInt(_kEmployeeId, employeeId);
    }
    if (projectId != null) {
      ApiClient.I.projectId = projectId;
      await sp.setInt(_kProjectId, projectId);
    }
    if (loginName != null) {
      _cachedLoginName = loginName;
      ApiClient.I.loginName = loginName;
      await sp.setString(_kLoginName, loginName);
    }
  }

  static Future<String> loadLoginName() async {
    final sp = await SharedPreferences.getInstance();
    _cachedLoginName = sp.getString(_kLoginName);
    return _cachedLoginName ?? '';
  }

  static Future<void> logout() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove(_kToken);
    ApiClient.I.clear();
  }
}
