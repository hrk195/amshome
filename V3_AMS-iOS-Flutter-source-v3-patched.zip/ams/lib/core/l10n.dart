import 'dart:convert';
import 'package:flutter/services.dart';

/// Bộ nạp bản dịch: dùng đúng bộ file ngôn ngữ của app gốc
/// (assets/locales/vi/*.json) nên toàn bộ chữ trên giao diện khớp 1:1 với bản Android.
class L {
  static final Map<String, String> _data = {};
  static bool _ready = false;

  static const List<String> _files = [
    'activation.json', 'address.json', 'attendant.json', 'change_password.json',
    'choose_project.json', 'coaching.json', 'common.json', 'create_shop.json',
    'dashboard.json', 'digital_map.json', 'display.json', 'document.json',
    'download.json', 'field_register.json', 'inventory.json',
    'inventory_tracking.json', 'kpi_history.json', 'kpi_result_history.json',
    'login.json', 'map_store.json', 'market_information.json',
    'notifications.json', 'ool.json', 'osa.json', 'pog.json', 'posm.json',
    'process.json', 'quick_test.json', 'register_working_plan.json',
    'report_summary.json', 'rpm_tracking.json', 'sellin.json', 'sellout.json',
    'shop_panel.json', 'sos.json', 'survey.json', 'transaction.json',
    'upload.json', 'welcome.json', 'work_result.json', 'working_plan.json',
  ];

  static Future<void> load() async {
    if (_ready) return;
    for (final f in _files) {
      try {
        final raw = await rootBundle.loadString('assets/locales/vi/$f');
        final map = json.decode(raw) as Map<String, dynamic>;
        map.forEach((k, v) {
          if (v is String) _data[k] = v;
        });
      } catch (_) {
        // một file lỗi không được làm chết app
      }
    }
    _ready = true;
  }

  /// Lấy chuỗi theo key, hỗ trợ tham số @name.
  static String t(String key, [Map<String, String>? params]) {
    var s = _data[key] ?? key;
    if (params != null) {
      params.forEach((k, v) => s = s.replaceAll('@$k', v));
    }
    return s;
  }

  static bool has(String key) => _data.containsKey(key);
}
