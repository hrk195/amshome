import 'package:flutter/material.dart';
import 'core/l10n.dart';
import 'core/session.dart';
import 'core/theme.dart';
import 'features/auth/login_page.dart';
import 'features/home/home_page.dart';

/// Chỉ dùng khi build thử giao diện, mặc định tắt.
const bool kDebugSkipLogin = bool.fromEnvironment('SKIP_LOGIN');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await L.load();
  await Session.init();
  runApp(const AmsApp());
}

class AmsApp extends StatelessWidget {
  const AmsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AMS',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(),
      locale: const Locale('vi', 'VN'),
      home: (kDebugSkipLogin || Session.isLoggedIn)
          ? const HomePage()
          : const LoginPage(),
    );
  }
}
